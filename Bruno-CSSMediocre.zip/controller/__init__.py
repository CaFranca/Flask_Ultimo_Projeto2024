# Importa todos os controladores necessários para a aplicação
from .AutorController import *  # Controlador relacionado aos autores
from .LivroController import *    # Controlador relacionado aos livros
from .CategoriasController import *  # Controlador relacionado às categorias
from .UsuarioController import *

